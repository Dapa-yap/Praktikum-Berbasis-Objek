public class Tiket {
    private String judulFilm;
    private double hargaDasar;
    private boolean statusPembayaran;
    public Tiket(String judulFilm, double hargaDasar) {
        this.judulFilm = judulFilm;
        if (hargaDasar < 0) {
            this.hargaDasar = 35000.0; 
        } else {
            this.hargaDasar = hargaDasar;
        }
        this.statusPembayaran = false; 
    }
    public void lakukanPembayaran() {
        this.statusPembayaran = true;
    }
    public String getJudulFilm() {
        return judulFilm;
    }
    public double getHargaDasar() {
        return hargaDasar;
    }
    public boolean isStatusPembayaran() {
        return statusPembayaran;
    }
}