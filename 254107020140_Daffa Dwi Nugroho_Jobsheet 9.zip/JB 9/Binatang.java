public class Binatang {
    
}
